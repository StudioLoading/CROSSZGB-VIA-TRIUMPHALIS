#include "Banks/SetAutoBank.h"

#include "ZGBMain.h"
#include "Palette.h"
#include "Scroll.h"
#include "Sprite.h"
#include "SpriteManager.h"

#include "custom_datas.h"

const UINT8 a_configelm_blink[] = {2, 0,1};
const UINT8 a_configelm[] = {1,1};

void item_configelm_anim_blink(Sprite* s_item_arg) BANKED;
void item_configelm_anim(Sprite* s_item_arg) BANKED;

extern void item_common_start(Sprite* s_item_arg) BANKED;
extern void item_common_update(Sprite* s_item_arg) BANKED;

void START(void){
    item_common_start(THIS);
}

void UPDATE(void){
    item_common_update(THIS);
}

void item_configelm_anim_blink(Sprite* s_item_arg) BANKED{
    SetSpriteAnim(s_item_arg, a_configelm_blink, 32);
}

void item_configelm_anim(Sprite* s_item_arg) BANKED{
    SetSpriteAnim(s_item_arg, a_configelm, 32);
}

void DESTROY(void){
    SetSpriteAnim(THIS, a_configelm, 32);
}