#ifndef CUSTOMDATAS_FILE
#define CUSTOMDATAS_FILE

typedef enum{
	EEE,
    ENE,
    NNE,
    NNN,
    NNW,
    WNW,
    WWW,
    WSW,
    SSW,
    SSS,
    SSE,
    ESE
}HORSE_DIRECTION;

typedef enum{
    TUTORIAL_STAGE_0_STRAIGHT,
    TUTORIAL_STAGE_1_STRAIGHTTIME,
    TUTORIAL_STAGE_2_TURNRIGHT,
    TUTORIAL_STAGE_3_TURNLEFT,
    TUTORIAL_STAGE_4_TURNRIGHTLEFT,
    TUTORIAL_STAGE_5_ZIGZAG,
    TUTORIAL_STAGE_6_ZIGZAG_ONTIME,
    TUTORIAL_STAGE_7_DODGEWATER,
    TUTORIAL_STAGE_8_GLADIO,
    TUTORIAL_STAGE_9_GLADIOLEFT,
    TUTORIAL_STAGE_10_LANCE,
    TUTORIAL_STAGE_11_CAPE,
    TUTORIAL_STAGE_12_STRAW,
    TUTORIAL_PASSED
}TUTORIAL_STAGE;

typedef enum{
    NONE,
    CLOCK,
    COUNTERCLOCK
}TURNING_VERSE;

typedef enum{
    NOITEM,
    FLAME,
    FOG,
    GLADIO,
    LANCE,
    ELMET,
    SHIELD,
    CAPE,
    HP,
    TIME,
    GOLDEN_WHIP,
    GOLDEN_WHEEL,
    GOLDEN_ELM,
    GOLDEN_REINS,
    ENEMY_LANCE,
    PAPYRUS
}ITEM_TYPE;

struct ItemData{
    INT8 vx;
    INT8 vy;
    INT8 hp;
    INT8 configured;//0 ignore, 1 set anim, 2 set anim for weapon in use, 3 to be picked up, 4 weapon in use
    ITEM_TYPE itemtype;
    UINT8 flag_continuous_spawning;
};

struct FlameData{
    INT8 vx;
    INT8 hp;
    INT8 dropped;//-1 donoth, 0 flaming, 1 cooldown, 2 just dropped
};

struct FantoccioData{
    INT8 fantoccio_counter;//se maggiore di 0 sta girando
};

typedef enum{
    LOOKING_FOR_SENATOR,
    SENATOR_COLLIDED,
    EXIT
}MISSION_STEP;

typedef enum{
    DESCRIPTION_GOLDEN_WHIP,
    DESCRIPTION_GOLDEN_WHEEL,
    DESCRIPTION_GOLDEN_REINS,
    DESCRIPTION_GOLDEN_ELM,
    TUTORIAL00_INTRO,
    TUTORIAL01_INTRO,
    TUTORIAL02_INTRO,
    TUTORIAL03_INTRO,
    TUTORIAL04_INTRO,
    TUTORIAL05_INTRO,
    TUTORIAL06_INTRO,
    TUTORIAL07_INTRO,
    TUTORIAL08_INTRO,
    TUTORIAL09_INTRO,
    TUTORIAL10_INTRO,
    TUTORIAL11_INTRO,
    TUTORIAL12_INTRO,
    MISSION00_INTRO,
    MISSION00_SECRET_MESSAGE,
    MISSION00_COMPLETED,
    MISSION01_INTRO,
    MISSION01_COMPLETED,
    MISSION02_INTRO,
    MISSION02_COMPLETED,
    MISSION03_INTRO,  
    MISSION03_COMPLETED,
    MISSION04_INTRO,
    MISSION04_COMPLETED,
    MISSION05_INTRO,
    MISSION05_SAVED_GENERAL,
    MISSION05_COMPLETED,
    MISSION06_INTRO,
    MISSION06_COMPLETED,
    MISSION07_INTRO,
    MISSION07_COMPLETED,
    MISSION08_INTRO,
    MISSION08_COMPLETED,
    MISSION09_INTRO,
    MISSION09_SAVED_AMBASSADOR,
    MISSION09_COMPLETED,
    MISSION10_INTRO,
    MISSION10_COMPLETED,
    MISSION11_INTRO,
    MISSION11_COMPLETED,
    MISSION12_INTRO,
    MISSION12_COMPLETED,
    MISSION13_INTRO,MISSION13_GENERAL_HEARD,
    MISSION13_COMPLETED,
    MISSION14_INTRO, MISSION14_COMPLETED,
    MISSION15_INTRO, MISSION15_COMPLETED,
    MISSION16_INTRO, MISSION16_COMPLETED,
    MISSION17_INTRO, MISSION17_COMPLETED,
    MISSION18_INTRO, MISSION18_BEDUIN_MESSAGE, MISSION18_COMPLETED,
    MISSION19_INTRO, MISSION19_STATUE_MESSAGE, MISSION19_COMPLETED,
    MISSION20_INTRO, MISSION20_COMPLETED,
    MISSION21_INTRO, MISSION21_COMPLETED,
    DEAD,
    DEMO_COMPLETED
}INSTRUCTION;

typedef enum{
    AREA_ROME,
    AREA_ALPS,
    AREA_SEA,
    AREA_GREECE,
    AREA_DESERT,
    AREA_EGYPT
}AREA;

typedef enum{
    MISSIONROME00,
    MISSIONROME01,
    MISSIONROME02,
    MISSIONROME03,
    MISSIONALPS04,
    MISSIONALPS05,
    MISSIONALPS06,
    MISSIONALPS07,
    MISSIONSEA08,
    MISSIONSEA09,
    MISSIONSEA10,
    MISSIONSEA11,
    MISSIONGREECE12,
    MISSIONGREECE13,
    MISSIONGREECE14,
    MISSIONGREECE15,
    MISSIONDESERT16,
    MISSIONDESERT17,
    MISSIONDESERT18,
    MISSIONEGYPT19,
    MISSIONEGYPT20,
    MISSIONEGYPT21,
}MISSION;

typedef enum{
    NORMAL,
    GOLDEN
}ITEM_CONFIGURATION;

struct CONFIGURATION{
    ITEM_CONFIGURATION elm;
    ITEM_CONFIGURATION wheel;
    ITEM_CONFIGURATION whip;
    ITEM_CONFIGURATION reins;
};

struct PointsData{
    UINT8 configured;
    UINT16 points;
    INT8 hp; 
};

typedef enum{
    PICKUP_GOLDEN,
    PICKUP_HP,
    ELANCE_DODGED,
    ENEMY_KILLED,
    HP_REMAINED,
    TIME_REMAINED,
    BY_ENEMY_HIT,
    BY_SKULL_HIT,
    BY_ELANCE_HIT,
}POINTS_TYPE;

struct LEVEL_POINTS{
    POINTS_TYPE points_type;
    INT16 points;
};

struct PharaoData {
    INT8 status;//0:normal; 1:hit; 2:dead;
    INT8 hp;
    INT8 counter;
};

struct SoldierData{
    INT8 vx;
    INT8 vy;
    UINT8 frmskip;
    UINT8 frmskip_max;
    INT8 configured;//0:unconfigured; 1:horizontal; 2:vertical; 3:walking, 4:dieing
    ITEM_TYPE reward;
    UINT8 points;
};

struct KillerData{
    UINT8 configured;//99: wait, 0: hidden, 1:blink, 2: visible, 3: blink&disappear
    INT8 timeout;
    UINT8 time_visible;
    UINT8 time_blink;
    UINT8 time_attack;
};

struct RollingStoneData{
    INT8 verse_x;
    INT8 frmskip_y;
    UINT8 max_frmskip_y;
};

struct SpawningMapRect{
    UINT16 box_x;
    UINT16 box_y;
    UINT16 box_width;
    UINT16 box_height;
    UINT8 box_flag_spawned;
    //struct SoldierData box_soldierdata;
    union {
        struct SoldierData soldier;
        struct KillerData killer;
        struct ItemData item;
    } box_data;
    UINT16 spawn_x;
    UINT16 spawn_y;
    SPRITE_TYPE type;
};


#endif