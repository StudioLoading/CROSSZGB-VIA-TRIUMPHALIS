#include "Banks/SetAutoBank.h"

#include "BankManager.h"
#include "ZGBMain.h"
#include "Keys.h"
#include "Palette.h"
#include "Scroll.h"
#include "Sprite.h"
#include "SpriteManager.h"
#include "string.h"
#include "Print.h"

#include "custom_datas.h"

IMPORT_MAP(mappoints);
IMPORT_TILES(font);

extern UINT8 flag_night_mode;
extern UINT8 turn_to_load;
extern MISSION current_mission;
extern MISSION_STEP current_step;
extern UINT8 turn;
extern UINT8 flag_is_demo;
extern INT8 world_area_map;
extern AREA current_area;
extern INT8 hp_current;
extern INT16 time_current;
extern INT8 mission_iscrono;
extern void state_move_to_papyrus(INSTRUCTION arg_instruction_to_show, UINT8 arg_prev_state) BANKED;
extern UINT16 get_points(void) BANKED;
extern void init_current_level_points(void) BANKED;
extern UINT16 add_points(POINTS_TYPE arg_points_type, INT16 arg_points) BANKED;

extern struct LEVEL_POINTS current_level_points[];
extern UINT16 current_points;

void move_to_mission_completed_papyrus(void) BANKED;
void calculate_mission_points(void) BANKED;

INT16 current_offset = 60;
INT8 current_point_idx = -1;
UINT8 showing_points = 1u;

void START(void){
    InitScroll(BANK(mappoints), &mappoints, 0, 0);
	SHOW_BKG;
	INIT_FONT(font, PRINT_BKG);
    PRINT(1, 1, "SCORE");
    SetWindowY(144);
    PRINT(1, 12, "CURRENT");
	calculate_mission_points();
	current_offset = 60;
	current_point_idx = -1;
	showing_points = 1u;
}

void UPDATE(void){
	if(showing_points){
		switch(current_point_idx){
			case -1:
				current_offset--;
				if(current_offset < 0){
					current_point_idx = 0;
					current_offset = 0;
					PRINT(1, 1, "PICKUP GOLDEN");
					PRINT(16, 1, "0000");
				}
			break;
			default:
				if(current_offset <= current_level_points[current_point_idx].points){
					UINT8 points_offset = 4;
					if(current_offset > 999){ points_offset = 0;}
					else if(current_offset > 99){ points_offset = 1;}
					else if(current_offset > 9){ points_offset = 2;}
					PRINT(16+points_offset, current_point_idx+1, "%u", current_offset);
					current_offset++;
					if(KEY_TICKED(J_A) || KEY_TICKED(J_B)){
						current_offset = current_level_points[current_point_idx].points;
					}
				}else{
					switch(current_point_idx){
						case 0: PRINT(1, 2, "PICKUP HP     -"); break;
						case 1: PRINT(1, 3, "LANCE DODGE"); break;
						case 2: PRINT(1, 4, "KILLINGS"); break;
						case 3: PRINT(1, 5, "LIFE"); break;
						case 4: PRINT(1, 6, "TIME"); break;
						case 5: PRINT(1, 7, "HIT           -"); break;
						case 6: PRINT(1, 8, "HIT BY SKULL  -"); break;
						case 7: PRINT(1, 9, "HIT BY LANCE  -"); break;
					}
					PRINT(16, current_point_idx+2, "0000");
					current_points += current_offset;
					current_point_idx++;
					current_offset = 0;
				}
			break;
			case 9:
				UINT16 current_points_to_show = get_points();
				PRINT(1, 13, "%u", current_points_to_show);
				showing_points = 0u;
			break;
		}
	}else{
		if(KEY_TICKED(J_START)){
			move_to_mission_completed_papyrus();
		}
	}
}

void calculate_mission_points(void) BANKED{
	//HP 
		add_points(HP_REMAINED, (UINT16)hp_current << 3);
	//TIME
		if(mission_iscrono){
			add_points(TIME_REMAINED, time_current);
		}
}

void move_to_mission_completed_papyrus(void) BANKED{
	flag_night_mode = 0;//RESET
	turn_to_load = turn;//missione successiva comincia nello stesso verso di dove finisce missione corrente
	INSTRUCTION instruction_to_give = 0;
	switch(current_mission){
		case MISSIONROME00: instruction_to_give = MISSION00_COMPLETED; break;
		case MISSIONROME01: 
			if(flag_is_demo){
				instruction_to_give = DEMO_COMPLETED; 
			}else{
				instruction_to_give = MISSION01_COMPLETED; 
			}
		break;
		case MISSIONROME02: 
			turn_to_load = 0;
			instruction_to_give = MISSION02_COMPLETED;
		break;
		case MISSIONROME03:
			world_area_map = 0;
			current_area = AREA_ALPS;
			instruction_to_give = MISSION03_COMPLETED;
		break;
		case MISSIONALPS04:
			instruction_to_give = MISSION04_COMPLETED; break;
		case MISSIONALPS05: 
			turn_to_load = 0;
			instruction_to_give = MISSION05_COMPLETED;
		break;
		case MISSIONALPS06: 
			turn_to_load = 0;
			instruction_to_give = MISSION06_COMPLETED;
		break;
		case MISSIONALPS07:
			world_area_map = 0;
			current_area = AREA_SEA;
			instruction_to_give = MISSION07_COMPLETED;
		break;
		case MISSIONSEA08: instruction_to_give = MISSION08_COMPLETED; break;
		case MISSIONSEA09: instruction_to_give = MISSION09_COMPLETED; break;
		case MISSIONSEA10: instruction_to_give = MISSION10_COMPLETED; break;
		case MISSIONSEA11: 
			current_area = AREA_GREECE;
			instruction_to_give = MISSION11_COMPLETED;
		break;
		case MISSIONGREECE12: instruction_to_give = MISSION12_COMPLETED;break;
		case MISSIONGREECE13: instruction_to_give = MISSION13_COMPLETED;break;
		case MISSIONGREECE14: instruction_to_give = MISSION14_COMPLETED;break;
		case MISSIONGREECE15: 
			current_area = AREA_DESERT;
			instruction_to_give = MISSION15_COMPLETED;
		break;
		case MISSIONDESERT16: instruction_to_give = MISSION16_COMPLETED; break;
		case MISSIONDESERT17: instruction_to_give = MISSION17_COMPLETED; break;
		case MISSIONDESERT18:
			current_area = AREA_EGYPT;
			instruction_to_give = MISSION18_COMPLETED;
		break;
		case MISSIONEGYPT19: instruction_to_give = MISSION19_COMPLETED; break;
		case MISSIONEGYPT20: instruction_to_give = MISSION20_COMPLETED; break;
		case MISSIONEGYPT21: instruction_to_give = MISSION21_COMPLETED; break;
	}
	current_mission++;
	current_step = LOOKING_FOR_SENATOR;
	init_current_level_points();
	state_move_to_papyrus(instruction_to_give, StateWorldmap);
}